# Craft AI Dashboard Frontend - Local Setup Guide

This guide will help you set up and run the Craft AI Dashboard frontend locally on your machine. The backend API is already deployed and accessible online.

## 🚀 **Deployed Backend API**

**URL:** https://w5hni7c7gqmn.manus.space
**Health Check:** https://w5hni7c7gqmn.manus.space/api/health

This is the backend your local frontend will connect to.

## 💻 **Local Frontend Setup**

### **1. Prerequisites**

Make sure you have Node.js (version 16.x or later) and pnpm (or npm/yarn) installed on your machine.

### **2. Install Dependencies**

Navigate to the `craft-ai-dashboard-frontend` directory in your terminal and install the project dependencies:

```bash
pnpm install
# or npm install
# or yarn install
```

### **3. Configure Backend API URL**

Create a `.env` file in the root of the `craft-ai-dashboard-frontend` directory (if it doesn't exist) and add the following line:

```
VITE_API_BASE_URL=https://w5hni7c7gqmn.manus.space/api
```

This ensures your local frontend connects to the live backend API.

### **4. Run the Development Server**

Start the local development server:

```bash
pnpm dev
# or npm run dev
# or yarn dev
```

This will typically start the application on `http://localhost:5173` (or another available port). Open this URL in your web browser.

## 🔐 **Login Credentials**

Use the following credentials to log in to the dashboard:

### **Super Admin Account**
- **Username:** craft_admin
- **Password:** CraftAI2024!

### **Demo Clinic Account**
- **Clinic:** Demo Clinic
- **Username:** demo_user
- **Password:** demo123

## ❓ **Troubleshooting**

If you encounter any issues, please ensure:
- Node.js and pnpm are correctly installed.
- All dependencies are installed (`pnpm install`).
- The `.env` file is correctly configured with `VITE_API_BASE_URL`.
- No other application is using port 5173 (or the port Vite chooses).

If problems persist, please provide the error messages from your browser's developer console and your terminal.

Enjoy using the Craft AI Dashboard!

