import { useState, useEffect } from 'react';
import { 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  MessageSquare,
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Search,
  Filter,
  Download,
  Plus,
  Edit,
  Trash2,
  MoreHorizontal,
  CalendarDays,
  MapPin,
  Mail,
  TrendingUp,
  TrendingDown
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from './ui/table';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from './ui/dropdown-menu';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import authService from '../lib/auth';

// Mock appointment data
const mockAppointments = [
  {
    id: 1,
    patient_name: 'John Doe',
    patient_phone: '+1234567890',
    patient_email: 'john.doe@email.com',
    appointment_date: '2024-01-18T14:00:00Z',
    service_type: 'Dental Cleaning',
    duration: 60,
    status: 'confirmed',
    confirmation_status: 'confirmed',
    confirmation_time: '2024-01-15T16:30:00Z',
    notes: 'Regular cleaning appointment',
    created_at: '2024-01-15T10:00:00Z',
    reminder_sent: true,
    last_reminder: '2024-01-17T09:00:00Z'
  },
  {
    id: 2,
    patient_name: 'Jane Smith',
    patient_phone: '+0987654321',
    patient_email: 'jane.smith@email.com',
    appointment_date: '2024-01-19T10:30:00Z',
    service_type: 'Consultation',
    duration: 30,
    status: 'pending',
    confirmation_status: 'pending',
    confirmation_time: null,
    notes: 'New patient consultation',
    created_at: '2024-01-15T14:30:00Z',
    reminder_sent: true,
    last_reminder: '2024-01-17T10:00:00Z'
  },
  {
    id: 3,
    patient_name: 'Mike Johnson',
    patient_phone: '+1122334455',
    patient_email: 'mike.johnson@email.com',
    appointment_date: '2024-01-20T15:00:00Z',
    service_type: 'Root Canal',
    duration: 90,
    status: 'rescheduled',
    confirmation_status: 'rescheduled',
    confirmation_time: '2024-01-16T11:00:00Z',
    notes: 'Rescheduled from original date',
    created_at: '2024-01-14T09:00:00Z',
    reminder_sent: false,
    last_reminder: null
  },
  {
    id: 4,
    patient_name: 'Sarah Wilson',
    patient_phone: '+5566778899',
    patient_email: 'sarah.wilson@email.com',
    appointment_date: '2024-01-17T09:00:00Z',
    service_type: 'Teeth Whitening',
    duration: 45,
    status: 'cancelled',
    confirmation_status: 'cancelled',
    confirmation_time: '2024-01-16T14:00:00Z',
    notes: 'Patient cancelled due to emergency',
    created_at: '2024-01-12T16:00:00Z',
    reminder_sent: true,
    last_reminder: '2024-01-16T09:00:00Z'
  }
];

// Mock confirmation responses
const mockConfirmations = [
  {
    id: 1,
    appointment_id: 1,
    patient_name: 'John Doe',
    response_type: 'confirmed',
    response_message: 'Yes, I confirm my appointment for Thursday at 2 PM',
    response_time: '2024-01-15T16:30:00Z',
    response_method: 'whatsapp'
  },
  {
    id: 2,
    appointment_id: 3,
    patient_name: 'Mike Johnson',
    response_type: 'rescheduled',
    response_message: 'Can we move this to Saturday instead?',
    response_time: '2024-01-16T11:00:00Z',
    response_method: 'sms'
  },
  {
    id: 3,
    appointment_id: 4,
    patient_name: 'Sarah Wilson',
    response_type: 'cancelled',
    response_message: 'Sorry, I need to cancel due to family emergency',
    response_time: '2024-01-16T14:00:00Z',
    response_method: 'phone'
  }
];

const appointmentStats = {
  total_appointments: 23,
  confirmed_appointments: 89,
  pending_appointments: 34,
  cancelled_appointments: 23,
  rescheduled_appointments: 10,
  confirmation_rate: 78,
  no_show_rate: 5,
  total_change: 8.7,
  confirmed_change: 12.3,
  pending_change: -5.2,
  no_show_change: -2.1
};

export default function Appointments() {
  const [appointments, setAppointments] = useState(mockAppointments);
  const [confirmations, setConfirmations] = useState(mockConfirmations);
  const [stats, setStats] = useState(appointmentStats);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('appointments');

  const user = authService.getCurrentUser();
  const clinic = authService.getCurrentClinic();

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    setLoading(true);
    try {
      // In real app, make API call here
      await new Promise(resolve => setTimeout(resolve, 1000));
      setAppointments(mockAppointments);
      setConfirmations(mockConfirmations);
      setStats(appointmentStats);
    } catch (error) {
      console.error('Failed to fetch appointments:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const variants = {
      confirmed: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      cancelled: 'bg-red-100 text-red-800',
      rescheduled: 'bg-blue-100 text-blue-800',
      completed: 'bg-gray-100 text-gray-800'
    };
    
    return (
      <Badge className={variants[status] || 'bg-gray-100 text-gray-800'}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending':
        return <AlertCircle className="h-4 w-4 text-yellow-600" />;
      case 'cancelled':
        return <XCircle className="h-4 w-4 text-red-600" />;
      case 'rescheduled':
        return <Calendar className="h-4 w-4 text-blue-600" />;
      default:
        return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  const formatTime = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const handleStatusChange = async (appointmentId, newStatus) => {
    try {
      // Update local state
      setAppointments(prevAppointments => 
        prevAppointments.map(apt => 
          apt.id === appointmentId 
            ? { ...apt, status: newStatus, confirmation_status: newStatus }
            : apt
        )
      );
      
      // In real app, make API call here
      console.log(`Updated appointment ${appointmentId} status to ${newStatus}`);
    } catch (error) {
      console.error('Failed to update appointment status:', error);
    }
  };

  const filteredAppointments = appointments.filter(apt => {
    const matchesSearch = !searchQuery || 
      apt.patient_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      apt.patient_phone.includes(searchQuery) ||
      apt.service_type?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || apt.status === statusFilter;
    
    // Date filter logic
    let matchesDate = true;
    if (dateFilter !== 'all') {
      const aptDate = new Date(apt.appointment_date);
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const nextWeek = new Date(today);
      nextWeek.setDate(nextWeek.getDate() + 7);
      
      switch (dateFilter) {
        case 'today':
          matchesDate = aptDate.toDateString() === today.toDateString();
          break;
        case 'tomorrow':
          matchesDate = aptDate.toDateString() === tomorrow.toDateString();
          break;
        case 'week':
          matchesDate = aptDate >= today && aptDate <= nextWeek;
          break;
      }
    }
    
    return matchesSearch && matchesStatus && matchesDate;
  });

  const StatCard = ({ title, value, change, icon: Icon, color = 'blue', suffix = '' }) => {
    const isPositive = change > 0;
    const isNegative = change < 0;
    const isNeutral = change === 0;
    
    // For no-show rate, negative change is positive (fewer no-shows is good)
    const isNoShow = title.toLowerCase().includes('no show');
    const effectiveIsPositive = isNoShow ? isNegative : isPositive;
    const effectiveIsNegative = isNoShow ? isPositive : isNegative;
    
    const colorClasses = {
      blue: 'bg-blue-50 text-blue-600',
      green: 'bg-green-50 text-green-600',
      yellow: 'bg-yellow-50 text-yellow-600',
      red: 'bg-red-50 text-red-600'
    };

    return (
      <Card className="shadow-sm border border-gray-100">
        <CardContent className="p-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-medium text-gray-600">{title}</p>
              <p className="text-xl font-bold text-gray-900 mt-0.5">{value}{suffix}</p>
              <div className="flex items-center mt-1">
                {effectiveIsPositive && (
                  <TrendingUp className="h-3 w-3 text-green-500 mr-1" />
                )}
                {effectiveIsNegative && (
                  <TrendingDown className="h-3 w-3 text-red-500 mr-1" />
                )}
                {isNeutral && (
                  <span className="h-3 w-3 bg-gray-300 rounded-full mr-1" />
                )}
                <span className={`text-xs font-medium ${
                  effectiveIsPositive ? 'text-green-600' : 
                  effectiveIsNegative ? 'text-red-600' : 
                  'text-gray-500'
                }`}>
                  {Math.abs(change)}%
                </span>
                <span className="text-xs text-gray-500 ml-1">vs yesterday</span>
              </div>
            </div>
            <div className={`p-2 rounded-lg ${colorClasses[color]}`}>
              <Icon className="h-4 w-4" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="p-4 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Appointments & Confirmations</h2>
          <p className="text-sm text-gray-600">Manage appointments and track patient confirmations</p>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" onClick={fetchAppointments} disabled={loading} className="h-8 text-xs">
            <Calendar className="h-3.5 w-3.5 mr-1.5" />
            Refresh
          </Button>
          <Button variant="outline" size="sm" className="h-8 text-xs">
            <Download className="h-3.5 w-3.5 mr-1.5" />
            Export
          </Button>
          <Button size="sm" className="craft-ai-teal h-8 text-xs">
            <Plus className="h-3.5 w-3.5 mr-1.5" />
            New Appointment
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Appointments"
          value={stats.total_appointments}
          change={stats.total_change}
          icon={Calendar}
          color="blue"
        />
        <StatCard
          title="Confirmed"
          value={stats.confirmed_appointments}
          change={stats.confirmed_change}
          icon={CheckCircle}
          color="green"
        />
        <StatCard
          title="Pending"
          value={stats.pending_appointments}
          change={stats.pending_change}
          icon={AlertCircle}
          color="yellow"
        />
        <StatCard
          title="No Show Rate"
          value={stats.no_show_rate}
          change={stats.no_show_change}
          icon={XCircle}
          color="red"
          suffix="%"
        />
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="appointments" className="text-xs">Appointments</TabsTrigger>
          <TabsTrigger value="confirmations" className="text-xs">Confirmation Responses</TabsTrigger>
        </TabsList>

        {/* Appointments Tab */}
        <TabsContent value="appointments">
          <Card className="shadow-sm">
            <CardHeader className="p-4 pb-2">
              <CardTitle className="text-base">Appointment Schedule</CardTitle>
              <CardDescription className="text-xs">View and manage all patient appointments</CardDescription>
              
              {/* Filters */}
              <div className="flex flex-col md:flex-row gap-3 mt-2">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3.5 w-3.5 text-gray-400" />
                    <Input
                      placeholder="Search by patient name, phone, or service..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-8 h-8 text-xs"
                    />
                  </div>
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-32 h-8 text-xs">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all" className="text-xs">All Status</SelectItem>
                    <SelectItem value="confirmed" className="text-xs">Confirmed</SelectItem>
                    <SelectItem value="pending" className="text-xs">Pending</SelectItem>
                    <SelectItem value="cancelled" className="text-xs">Cancelled</SelectItem>
                    <SelectItem value="rescheduled" className="text-xs">Rescheduled</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={dateFilter} onValueChange={setDateFilter}>
                  <SelectTrigger className="w-32 h-8 text-xs">
                    <SelectValue placeholder="Date" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all" className="text-xs">All Dates</SelectItem>
                    <SelectItem value="today" className="text-xs">Today</SelectItem>
                    <SelectItem value="tomorrow" className="text-xs">Tomorrow</SelectItem>
                    <SelectItem value="week" className="text-xs">This Week</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="text-xs">Patient</TableHead>
                      <TableHead className="text-xs">Service</TableHead>
                      <TableHead className="text-xs">Date & Time</TableHead>
                      <TableHead className="text-xs">Duration</TableHead>
                      <TableHead className="text-xs">Status</TableHead>
                      <TableHead className="text-xs">Confirmation</TableHead>
                      <TableHead className="text-xs">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAppointments.map((appointment) => (
                      <TableRow key={appointment.id}>
                        <TableCell className="text-xs">
                          <div>
                            <div className="font-medium">{appointment.patient_name}</div>
                            <div className="text-xs text-gray-500 flex items-center space-x-1">
                              <Phone className="h-3 w-3" />
                              <span>{appointment.patient_phone}</span>
                            </div>
                            <div className="text-xs text-gray-500 flex items-center space-x-1">
                              <Mail className="h-3 w-3" />
                              <span>{appointment.patient_email}</span>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-xs">
                          <div>
                            <div className="font-medium">{appointment.service_type}</div>
                            {appointment.notes && (
                              <div className="text-xs text-gray-500">{appointment.notes}</div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs">
                          <div>
                            <div className="font-medium">{formatDate(appointment.appointment_date)}</div>
                            <div className="text-xs text-gray-500">{formatTime(appointment.appointment_date)}</div>
                          </div>
                        </TableCell>
                        <TableCell className="text-xs">
                          <div className="flex items-center space-x-1">
                            <Clock className="h-3.5 w-3.5 text-gray-400" />
                            <span>{appointment.duration} min</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-xs">
                          <div className="flex items-center space-x-1">
                            {getStatusIcon(appointment.status)}
                            {getStatusBadge(appointment.status)}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs">
                          <div>
                            {appointment.confirmation_time ? (
                              <div>
                                <div className="font-medium text-green-600">Responded</div>
                                <div className="text-gray-500">{formatDateTime(appointment.confirmation_time)}</div>
                              </div>
                            ) : (
                              <div className="text-yellow-600">Awaiting Response</div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-7 w-7">
                                <MoreHorizontal className="h-3.5 w-3.5" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel className="text-xs">Update Status</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => handleStatusChange(appointment.id, 'confirmed')} className="text-xs">
                                <CheckCircle className="h-3.5 w-3.5 mr-2" />
                                Mark Confirmed
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleStatusChange(appointment.id, 'rescheduled')} className="text-xs">
                                <Calendar className="h-3.5 w-3.5 mr-2" />
                                Reschedule
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleStatusChange(appointment.id, 'cancelled')} className="text-xs">
                                <XCircle className="h-3.5 w-3.5 mr-2" />
                                Cancel
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem className="text-xs">
                                <Phone className="h-3.5 w-3.5 mr-2" />
                                Call Patient
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-xs">
                                <MessageSquare className="h-3.5 w-3.5 mr-2" />
                                Send Message
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {filteredAppointments.length === 0 && (
                <div className="text-center py-6">
                  <Calendar className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                  <p className="text-xs text-gray-500">No appointments found matching your criteria</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Confirmations Tab */}
        <TabsContent value="confirmations">
          <Card className="shadow-sm">
            <CardHeader className="p-4 pb-2">
              <CardTitle className="text-base">Patient Confirmation Responses</CardTitle>
              <CardDescription className="text-xs">Track patient replies to appointment confirmations</CardDescription>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-3">
                {confirmations.map((confirmation) => (
                  <div key={confirmation.id} className="border rounded-lg p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h4 className="font-medium text-xs">{confirmation.patient_name}</h4>
                        <p className="text-[10px] text-gray-500">{formatDateTime(confirmation.response_time)}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        {getStatusBadge(confirmation.response_type)}
                        <Badge variant="outline" className="text-[10px]">
                          {confirmation.response_method.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-2">
                      <p className="text-xs italic">"{confirmation.response_message}"</p>
                    </div>
                  </div>
                ))}
              </div>

              {confirmations.length === 0 && (
                <div className="text-center py-6">
                  <MessageSquare className="h-10 w-10 text-gray-400 mx-auto mb-3" />
                  <p className="text-xs text-gray-500">No confirmation responses yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

