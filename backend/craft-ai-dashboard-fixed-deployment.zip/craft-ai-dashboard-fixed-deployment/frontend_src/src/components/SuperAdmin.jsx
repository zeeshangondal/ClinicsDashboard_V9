import { useState, useEffect } from 'react';
import { 
  Building2, 
  Users, 
  Activity, 
  DollarSign, 
  Plus, 
  Search, 
  Filter, 
  MoreHorizontal,
  Edit,
  Trash2,
  Eye,
  Crown,
  Shield,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  Calendar,
  Download,
  RefreshCw,
  Settings,
  Database,
  Server,
  Zap,
  Globe
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { 
  LineChart, 
  Line, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import authService from '../lib/auth';

// Mock data for Super Admin Dashboard
const mockSystemMetrics = {
  total_clinics: 24,
  active_clinics: 22,
  total_users: 156,
  active_users: 142,
  total_calls_today: 1247,
  total_messages_today: 3456,
  system_health: 98.5,
  uptime_percentage: 99.9,
  avg_response_time: 245,
  storage_used: 67.3,
  bandwidth_used: 45.2
};

const mockClinics = [
  {
    id: 1,
    name: 'Downtown Medical Center',
    subscription: 'Premium',
    status: 'active',
    users: 12,
    calls_today: 156,
    messages_today: 234,
    last_activity: '2024-01-15T14:30:00Z',
    created_at: '2023-06-15T09:00:00Z',
    monthly_usage: 89.5,
    billing_status: 'paid'
  },
  {
    id: 2,
    name: 'Westside Dental Clinic',
    subscription: 'Standard',
    status: 'active',
    users: 8,
    calls_today: 89,
    messages_today: 167,
    last_activity: '2024-01-15T13:45:00Z',
    created_at: '2023-08-22T10:30:00Z',
    monthly_usage: 67.2,
    billing_status: 'paid'
  },
  {
    id: 3,
    name: 'Family Health Associates',
    subscription: 'Basic',
    status: 'inactive',
    users: 4,
    calls_today: 0,
    messages_today: 0,
    last_activity: '2024-01-12T16:20:00Z',
    created_at: '2023-11-10T14:15:00Z',
    monthly_usage: 23.1,
    billing_status: 'overdue'
  },
  {
    id: 4,
    name: 'Sunrise Pediatrics',
    subscription: 'Premium',
    status: 'active',
    users: 15,
    calls_today: 203,
    messages_today: 345,
    last_activity: '2024-01-15T14:25:00Z',
    created_at: '2023-04-08T11:45:00Z',
    monthly_usage: 92.8,
    billing_status: 'paid'
  },
  {
    id: 5,
    name: 'Metro Orthopedic Center',
    subscription: 'Standard',
    status: 'trial',
    users: 6,
    calls_today: 45,
    messages_today: 78,
    last_activity: '2024-01-15T12:10:00Z',
    created_at: '2024-01-01T09:30:00Z',
    monthly_usage: 34.5,
    billing_status: 'trial'
  }
];

const mockUsageData = [
  { month: 'Jul', calls: 12450, messages: 23400, clinics: 18 },
  { month: 'Aug', calls: 15600, messages: 28900, clinics: 19 },
  { month: 'Sep', calls: 18200, messages: 34500, clinics: 21 },
  { month: 'Oct', calls: 21300, messages: 41200, clinics: 22 },
  { month: 'Nov', calls: 24800, messages: 47800, clinics: 23 },
  { month: 'Dec', calls: 28900, messages: 52300, clinics: 24 },
  { month: 'Jan', calls: 31200, messages: 56700, clinics: 24 }
];

const mockSubscriptionData = [
  { name: 'Premium', value: 45, color: '#006572' },
  { name: 'Standard', value: 35, color: '#f8cb0c' },
  { name: 'Basic', value: 15, color: '#10b981' },
  { name: 'Trial', value: 5, color: '#6b7280' }
];

const mockSystemLogs = [
  {
    id: 1,
    timestamp: '2024-01-15T14:30:00Z',
    level: 'info',
    category: 'auth',
    message: 'User login successful',
    clinic: 'Downtown Medical Center',
    user: 'john.doe@downtown.com',
    ip: '192.168.1.100'
  },
  {
    id: 2,
    timestamp: '2024-01-15T14:25:00Z',
    level: 'warning',
    category: 'api',
    message: 'Rate limit approaching for WhatsApp API',
    clinic: 'Sunrise Pediatrics',
    user: 'system',
    ip: 'internal'
  },
  {
    id: 3,
    timestamp: '2024-01-15T14:20:00Z',
    level: 'error',
    category: 'webhook',
    message: 'WhatsApp webhook verification failed',
    clinic: 'Family Health Associates',
    user: 'system',
    ip: 'external'
  },
  {
    id: 4,
    timestamp: '2024-01-15T14:15:00Z',
    level: 'info',
    category: 'billing',
    message: 'Monthly subscription renewed',
    clinic: 'Westside Dental Clinic',
    user: 'billing-system',
    ip: 'internal'
  }
];

export default function SuperAdmin() {
  const [activeTab, setActiveTab] = useState('overview');
  const [clinics, setClinics] = useState(mockClinics);
  const [systemMetrics, setSystemMetrics] = useState(mockSystemMetrics);
  const [systemLogs, setSystemLogs] = useState(mockSystemLogs);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [subscriptionFilter, setSubscriptionFilter] = useState('all');
  const [showAddClinicDialog, setShowAddClinicDialog] = useState(false);
  const [newClinic, setNewClinic] = useState({
    name: '',
    subscription: 'Standard',
    admin_email: '',
    admin_name: ''
  });

  const user = authService.getCurrentUser();

  useEffect(() => {
    fetchSystemData();
  }, []);

  const fetchSystemData = async () => {
    setLoading(true);
    try {
      // In real app, make API calls here
      await new Promise(resolve => setTimeout(resolve, 1000));
      setClinics(mockClinics);
      setSystemMetrics(mockSystemMetrics);
      setSystemLogs(mockSystemLogs);
    } catch (error) {
      console.error('Failed to fetch system data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddClinic = async () => {
    try {
      // In real app, make API call here
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const clinic = {
        id: Date.now(),
        name: newClinic.name,
        subscription: newClinic.subscription,
        status: 'trial',
        users: 1,
        calls_today: 0,
        messages_today: 0,
        last_activity: new Date().toISOString(),
        created_at: new Date().toISOString(),
        monthly_usage: 0,
        billing_status: 'trial'
      };
      
      setClinics(prev => [clinic, ...prev]);
      setNewClinic({ name: '', subscription: 'Standard', admin_email: '', admin_name: '' });
      setShowAddClinicDialog(false);
      
      console.log('Clinic added successfully');
    } catch (error) {
      console.error('Failed to add clinic:', error);
    }
  };

  const handleUpdateClinicStatus = async (clinicId, newStatus) => {
    try {
      setClinics(prev => prev.map(clinic => 
        clinic.id === clinicId ? { ...clinic, status: newStatus } : clinic
      ));
      console.log('Clinic status updated');
    } catch (error) {
      console.error('Failed to update clinic status:', error);
    }
  };

  const filteredClinics = clinics.filter(clinic => {
    const matchesSearch = clinic.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || clinic.status === statusFilter;
    const matchesSubscription = subscriptionFilter === 'all' || clinic.subscription === subscriptionFilter;
    return matchesSearch && matchesStatus && matchesSubscription;
  });

  const getStatusBadge = (status) => {
    const variants = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-red-100 text-red-800',
      trial: 'bg-blue-100 text-blue-800',
      suspended: 'bg-yellow-100 text-yellow-800'
    };
    
    return (
      <Badge className={variants[status] || 'bg-gray-100 text-gray-800'}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  const getBillingBadge = (status) => {
    const variants = {
      paid: 'bg-green-100 text-green-800',
      overdue: 'bg-red-100 text-red-800',
      trial: 'bg-blue-100 text-blue-800',
      cancelled: 'bg-gray-100 text-gray-800'
    };
    
    return (
      <Badge className={variants[status] || 'bg-gray-100 text-gray-800'}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  const getLogLevelIcon = (level) => {
    switch (level) {
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'info':
        return <CheckCircle className="h-4 w-4 text-blue-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const formatNumber = (num) => {
    return new Intl.NumberFormat().format(num);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Crown className="h-8 w-8 text-yellow-500" />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Super Admin Dashboard</h2>
            <p className="text-gray-600">System-wide management and analytics</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={fetchSystemData} disabled={loading}>
            {loading ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4 mr-2" />
            )}
            Refresh
          </Button>
          <Button onClick={() => setShowAddClinicDialog(true)} className="craft-ai-teal">
            <Plus className="h-4 w-4 mr-2" />
            Add Clinic
          </Button>
        </div>
      </div>

      {/* System Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Clinics</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{systemMetrics.total_clinics}</div>
            <p className="text-xs text-muted-foreground">
              {systemMetrics.active_clinics} active
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(systemMetrics.total_users)}</div>
            <p className="text-xs text-muted-foreground">
              {systemMetrics.active_users} active today
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Calls Today</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(systemMetrics.total_calls_today)}</div>
            <p className="text-xs text-muted-foreground">
              +12% from yesterday
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Messages Today</CardTitle>
            <Zap className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(systemMetrics.total_messages_today)}</div>
            <p className="text-xs text-muted-foreground">
              +8% from yesterday
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">System Overview</TabsTrigger>
          <TabsTrigger value="clinics">Clinic Management</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="logs">System Logs</TabsTrigger>
        </TabsList>

        {/* System Overview Tab */}
        <TabsContent value="overview">
          <div className="grid gap-6">
            {/* System Health Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Server className="h-5 w-5" />
                    <span>System Health</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    {systemMetrics.system_health}%
                  </div>
                  <Progress value={systemMetrics.system_health} className="mb-2" />
                  <p className="text-sm text-gray-600">All systems operational</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Globe className="h-5 w-5" />
                    <span>Uptime</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-green-600 mb-2">
                    {systemMetrics.uptime_percentage}%
                  </div>
                  <Progress value={systemMetrics.uptime_percentage} className="mb-2" />
                  <p className="text-sm text-gray-600">30 days average</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Database className="h-5 w-5" />
                    <span>Storage Usage</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-blue-600 mb-2">
                    {systemMetrics.storage_used}%
                  </div>
                  <Progress value={systemMetrics.storage_used} className="mb-2" />
                  <p className="text-sm text-gray-600">2.3TB of 3.4TB used</p>
                </CardContent>
              </Card>
            </div>

            {/* Usage Trends Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Usage Trends</CardTitle>
                <CardDescription>System usage over the last 7 months</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={mockUsageData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Area 
                      type="monotone" 
                      dataKey="calls" 
                      stackId="1" 
                      stroke="#006572" 
                      fill="#006572" 
                      fillOpacity={0.6}
                      name="Calls"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="messages" 
                      stackId="1" 
                      stroke="#f8cb0c" 
                      fill="#f8cb0c" 
                      fillOpacity={0.6}
                      name="Messages"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Clinic Management Tab */}
        <TabsContent value="clinics">
          <div className="space-y-6">
            {/* Filters */}
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <Input
                  placeholder="Search clinics..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-sm"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="trial">Trial</SelectItem>
                  <SelectItem value="suspended">Suspended</SelectItem>
                </SelectContent>
              </Select>
              <Select value={subscriptionFilter} onValueChange={setSubscriptionFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by plan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Plans</SelectItem>
                  <SelectItem value="Premium">Premium</SelectItem>
                  <SelectItem value="Standard">Standard</SelectItem>
                  <SelectItem value="Basic">Basic</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Clinics Table */}
            <Card>
              <CardHeader>
                <CardTitle>Clinic Management</CardTitle>
                <CardDescription>
                  Manage all registered clinics and their subscriptions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Clinic Name</TableHead>
                      <TableHead>Subscription</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Users</TableHead>
                      <TableHead>Today's Activity</TableHead>
                      <TableHead>Billing</TableHead>
                      <TableHead>Last Activity</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredClinics.map((clinic) => (
                      <TableRow key={clinic.id}>
                        <TableCell className="font-medium">{clinic.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{clinic.subscription}</Badge>
                        </TableCell>
                        <TableCell>{getStatusBadge(clinic.status)}</TableCell>
                        <TableCell>{clinic.users}</TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <div>{clinic.calls_today} calls</div>
                            <div className="text-gray-500">{clinic.messages_today} messages</div>
                          </div>
                        </TableCell>
                        <TableCell>{getBillingBadge(clinic.billing_status)}</TableCell>
                        <TableCell className="text-sm">
                          {formatDateTime(clinic.last_activity)}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem>
                                <Eye className="mr-2 h-4 w-4" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Edit className="mr-2 h-4 w-4" />
                                Edit Clinic
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                onClick={() => handleUpdateClinicStatus(clinic.id, 
                                  clinic.status === 'active' ? 'inactive' : 'active'
                                )}
                              >
                                {clinic.status === 'active' ? (
                                  <>
                                    <XCircle className="mr-2 h-4 w-4" />
                                    Deactivate
                                  </>
                                ) : (
                                  <>
                                    <CheckCircle className="mr-2 h-4 w-4" />
                                    Activate
                                  </>
                                )}
                              </DropdownMenuItem>
                              <DropdownMenuItem className="text-red-600">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete Clinic
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics">
          <div className="grid gap-6">
            {/* Subscription Distribution */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Subscription Distribution</CardTitle>
                  <CardDescription>Breakdown of clinic subscription plans</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={mockSubscriptionData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {mockSubscriptionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Monthly Growth</CardTitle>
                  <CardDescription>Clinic growth over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={mockUsageData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="clinics" 
                        stroke="#006572" 
                        strokeWidth={3}
                        name="Clinics"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            {/* Usage Statistics */}
            <Card>
              <CardHeader>
                <CardTitle>Usage Statistics</CardTitle>
                <CardDescription>Calls and messages volume trends</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={mockUsageData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="calls" fill="#006572" name="Calls" />
                    <Bar dataKey="messages" fill="#f8cb0c" name="Messages" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* System Logs Tab */}
        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <CardTitle>System Logs</CardTitle>
              <CardDescription>
                Recent system events and activities across all clinics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {systemLogs.map((log) => (
                  <div key={log.id} className="flex items-start space-x-4 p-4 border rounded-lg">
                    <div className="flex-shrink-0 mt-1">
                      {getLogLevelIcon(log.level)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-sm font-medium text-gray-900">
                          {log.message}
                        </p>
                        <p className="text-xs text-gray-500">
                          {formatDateTime(log.timestamp)}
                        </p>
                      </div>
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span>Category: {log.category}</span>
                        <span>Clinic: {log.clinic}</span>
                        <span>User: {log.user}</span>
                        <span>IP: {log.ip}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Add Clinic Dialog */}
      <Dialog open={showAddClinicDialog} onOpenChange={setShowAddClinicDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add New Clinic</DialogTitle>
            <DialogDescription>
              Create a new clinic account with initial admin user.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="clinic-name" className="text-right">
                Clinic Name
              </Label>
              <Input
                id="clinic-name"
                value={newClinic.name}
                onChange={(e) => setNewClinic(prev => ({ ...prev, name: e.target.value }))}
                className="col-span-3"
                placeholder="Enter clinic name"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="subscription" className="text-right">
                Subscription
              </Label>
              <Select 
                value={newClinic.subscription} 
                onValueChange={(value) => setNewClinic(prev => ({ ...prev, subscription: value }))}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Basic">Basic</SelectItem>
                  <SelectItem value="Standard">Standard</SelectItem>
                  <SelectItem value="Premium">Premium</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="admin-name" className="text-right">
                Admin Name
              </Label>
              <Input
                id="admin-name"
                value={newClinic.admin_name}
                onChange={(e) => setNewClinic(prev => ({ ...prev, admin_name: e.target.value }))}
                className="col-span-3"
                placeholder="Admin full name"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="admin-email" className="text-right">
                Admin Email
              </Label>
              <Input
                id="admin-email"
                type="email"
                value={newClinic.admin_email}
                onChange={(e) => setNewClinic(prev => ({ ...prev, admin_email: e.target.value }))}
                className="col-span-3"
                placeholder="admin@clinic.com"
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              type="submit" 
              onClick={handleAddClinic}
              className="craft-ai-teal"
            >
              Create Clinic
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

