import { useState, useEffect } from 'react';
import { Bell, Search, Settings, User, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from './ui/dropdown-menu';
import authService from '../lib/auth';

export default function Header({ title, onSearch, onRefresh }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [notifications, setNotifications] = useState([]);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  
  const user = authService.getCurrentUser();
  const clinic = authService.getCurrentClinic();

  useEffect(() => {
    // Simulate real-time notifications
    const interval = setInterval(() => {
      // This would be replaced with real WebSocket notifications
      const mockNotifications = [
        { id: 1, message: 'New WhatsApp message received', time: '2 min ago', unread: true },
        { id: 2, message: 'Call completed successfully', time: '5 min ago', unread: true },
        { id: 3, message: 'Appointment confirmed', time: '10 min ago', unread: false },
      ];
      setNotifications(mockNotifications);
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (onSearch) {
      onSearch(searchQuery);
    }
  };

  const handleRefresh = () => {
    setLastRefresh(new Date());
    if (onRefresh) {
      onRefresh();
    }
  };

  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <header className="bg-white border-b border-gray-200 px-3 py-2">
      <div className="flex items-center justify-between">
        {/* Left Section - Title and Breadcrumb */}
        <div className="flex items-center space-x-3">
          <div>
            <h1 className="text-lg font-semibold text-gray-900">
              {title}
            </h1>
            {clinic && (
              <p className="text-xs text-gray-500">
                {clinic.name} • {user?.role?.replace('_', ' ').toUpperCase()}
              </p>
            )}
          </div>
        </div>

        {/* Center Section - Search */}
        <div className="flex-1 max-w-md mx-6">
          <form onSubmit={handleSearch} className="relative">
            <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3.5 w-3.5 text-gray-400" />
            <Input
              type="text"
              placeholder="Search calls, messages, appointments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 pr-3 py-1.5 w-full h-8 text-sm"
            />
          </form>
        </div>

        {/* Right Section - Actions and User Menu */}
        <div className="flex items-center space-x-2">
          {/* Refresh Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            className="text-gray-500 hover:text-gray-700 h-8 w-8 p-1.5"
            title="Refresh data"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>

          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="relative h-8 w-8 p-1.5">
                <Bell className="h-4 w-4" />
                {unreadCount > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-1 -right-1 h-4 w-4 flex items-center justify-center p-0 text-[10px]"
                  >
                    {unreadCount}
                  </Badge>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-72">
              <DropdownMenuLabel className="text-xs py-1.5">Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {notifications.length > 0 ? (
                notifications.map((notification) => (
                  <DropdownMenuItem key={notification.id} className="flex flex-col items-start p-2">
                    <div className="flex items-center justify-between w-full">
                      <span className={`text-xs ${notification.unread ? 'font-medium' : 'text-gray-600'}`}>
                        {notification.message}
                      </span>
                      {notification.unread && (
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full ml-2" />
                      )}
                    </div>
                    <span className="text-[10px] text-gray-500 mt-0.5">{notification.time}</span>
                  </DropdownMenuItem>
                ))
              ) : (
                <DropdownMenuItem disabled>
                  <span className="text-xs text-gray-500">No new notifications</span>
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User Menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center space-x-2 px-2 h-8">
                <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                  <span className="text-[10px] font-medium text-primary-foreground">
                    {user?.first_name?.[0] || user?.username?.[0]?.toUpperCase() || 'U'}
                  </span>
                </div>
                <div className="hidden md:block text-left">
                  <p className="text-xs font-medium">
                    {user?.first_name || user?.username}
                  </p>
                  <p className="text-[10px] text-gray-500">
                    {user?.email}
                  </p>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel className="text-xs py-1.5">My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-xs py-1.5">
                <User className="mr-2 h-3 w-3" />
                <span>Profile</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="text-xs py-1.5">
                <Settings className="mr-2 h-3 w-3" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600 text-xs py-1.5">
                <span>Sign out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Status Bar */}
      <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-gray-100">
        <div className="flex items-center space-x-3 text-[10px] text-gray-500">
          <span>Last updated: {lastRefresh.toLocaleTimeString()}</span>
          {clinic && (
            <>
              <span>•</span>
              <span className="flex items-center space-x-1">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full"></div>
                <span>System Online</span>
              </span>
            </>
          )}
        </div>
        
        {clinic && (
          <div className="flex items-center space-x-3 text-[10px]">
            <Badge variant="outline" className="craft-ai-border-teal craft-ai-text-teal text-[10px] h-5 py-0">
              {clinic.subscription_plan?.toUpperCase()}
            </Badge>
            <span className="text-gray-500">
              Subscription: {clinic.subscription_status}
            </span>
          </div>
        )}
      </div>
    </header>
  );
}

