import { useState } from 'react';
import { Eye, EyeOff, Brain, Loader2 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import authService from '../lib/auth';
import craftAiLogo from '../assets/craft-ai-logo.png';
import '../App.css';

export default function Login({ onLogin }) {
  const [formData, setFormData] = useState({
    clinicName: '',
    username: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user starts typing
    if (error) setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { clinicName, username, password } = formData;
      
      if (!clinicName.trim() || !username.trim() || !password) {
        throw new Error('All fields are required');
      }

      const result = await authService.login(clinicName.trim(), username.trim(), password);
      onLogin(result);
    } catch (err) {
      setError(err.message || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen login-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg border border-gray-100 bg-white relative z-10">
        <CardHeader className="text-center space-y-3 bg-primary rounded-t-lg pb-6">
          <div className="flex justify-center">
            <img 
              src={craftAiLogo} 
              alt="Craft AI" 
              className="w-14 h-14 object-contain"
            />
          </div>
          <div>
            <CardTitle className="text-xl font-bold text-white">
              Craft AI Dashboard
            </CardTitle>
            <CardDescription className="text-gray-100 mt-1 text-sm">
              Multi-Clinic Management Platform
            </CardDescription>
          </div>
        </CardHeader>
        
        <CardContent className="p-6 pt-8 bg-gray-50 relative z-20">
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription className="text-sm">{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="clinicName" className="text-sm font-medium text-gray-700">
                Clinic Name
              </Label>
              <Input
                id="clinicName"
                name="clinicName"
                type="text"
                placeholder="Enter your clinic name"
                value={formData.clinicName}
                onChange={handleInputChange}
                disabled={loading}
                className="border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary text-sm h-10 bg-white relative z-30"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="username" className="text-sm font-medium text-gray-700">
                Username
              </Label>
              <Input
                id="username"
                name="username"
                type="text"
                placeholder="Enter your username"
                value={formData.username}
                onChange={handleInputChange}
                disabled={loading}
                className="border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary text-sm h-10 bg-white relative z-30"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                Password
              </Label>
              <div className="relative z-30">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={handleInputChange}
                  disabled={loading}
                  className="border-gray-300 focus:border-primary focus:ring-1 focus:ring-primary pr-10 text-sm h-10 bg-white"
                  required
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center z-40"
                  onClick={() => setShowPassword(!showPassword)}
                  disabled={loading}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400 hover:text-gray-600" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400 hover:text-gray-600" />
                  )}
                </button>
              </div>
            </div>
            
            <Button
              type="submit"
              className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-2 text-sm h-10 mt-4 relative z-30"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing In...
                </>
              ) : (
                'Sign In'
              )}
            </Button>
          </form>
          
          <div className="mt-6 pt-4 border-t border-gray-200 text-center">
            <div className="text-sm font-medium text-gray-700">
              Demo Credentials
            </div>
            <div className="text-xs text-gray-500 mt-1 space-y-1">
              <div>Super Admin: craft_admin / CraftAI2024!</div>
              <div>Clinic User: demo / demo (with any clinic name)</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

