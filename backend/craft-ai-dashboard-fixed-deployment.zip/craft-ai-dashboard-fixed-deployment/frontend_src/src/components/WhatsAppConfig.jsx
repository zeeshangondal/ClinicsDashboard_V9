import { useState, useEffect } from 'react';
import { 
  MessageSquare, 
  Phone, 
  Key, 
  Link, 
  Save, 
  TestTube,
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Eye,
  EyeOff,
  Copy,
  RefreshCw,
  Settings,
  Webhook,
  Shield,
  Info
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { 
  Alert,
  AlertDescription,
  AlertTitle,
} from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import authService from '../lib/auth';

// Mock WhatsApp configuration data
const mockConfig = {
  phone_number_id: '1234567890123456',
  access_token: 'EAABwzLixnjYBOxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx',
  webhook_url: 'https://api.craftai.com/webhook/whatsapp',
  webhook_verify_token: 'craft_ai_verify_token_2024',
  business_account_id: '9876543210987654',
  app_id: '1122334455667788',
  app_secret: 'abcd1234efgh5678ijkl9012mnop3456',
  webhook_events: ['messages', 'messaging_postbacks', 'messaging_optins'],
  is_webhook_verified: true,
  last_test_time: '2024-01-15T14:30:00Z',
  test_status: 'success',
  created_at: '2024-01-10T09:00:00Z',
  updated_at: '2024-01-15T14:30:00Z'
};

const mockTestResults = [
  {
    id: 1,
    test_type: 'send_message',
    status: 'success',
    message: 'Test message sent successfully',
    timestamp: '2024-01-15T14:30:00Z',
    response_time: 245
  },
  {
    id: 2,
    test_type: 'webhook_verification',
    status: 'success',
    message: 'Webhook verified successfully',
    timestamp: '2024-01-15T14:25:00Z',
    response_time: 120
  },
  {
    id: 3,
    test_type: 'receive_message',
    status: 'success',
    message: 'Webhook receiving messages correctly',
    timestamp: '2024-01-15T14:20:00Z',
    response_time: 89
  }
];

export default function WhatsAppConfig() {
  const [config, setConfig] = useState(mockConfig);
  const [testResults, setTestResults] = useState(mockTestResults);
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showAccessToken, setShowAccessToken] = useState(false);
  const [showAppSecret, setShowAppSecret] = useState(false);
  const [activeTab, setActiveTab] = useState('configuration');

  const user = authService.getCurrentUser();
  const clinic = authService.getCurrentClinic();

  useEffect(() => {
    fetchConfiguration();
  }, []);

  const fetchConfiguration = async () => {
    setLoading(true);
    try {
      // In real app, make API call here
      await new Promise(resolve => setTimeout(resolve, 1000));
      setConfig(mockConfig);
      setTestResults(mockTestResults);
    } catch (error) {
      console.error('Failed to fetch configuration:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveConfiguration = async () => {
    setSaving(true);
    try {
      // In real app, make API call here
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Update timestamps
      setConfig(prev => ({
        ...prev,
        updated_at: new Date().toISOString()
      }));
      
      console.log('Configuration saved successfully');
    } catch (error) {
      console.error('Failed to save configuration:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleTestConnection = async (testType = 'full') => {
    setTesting(true);
    try {
      // In real app, make API call here
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      const newTestResult = {
        id: Date.now(),
        test_type: testType,
        status: 'success',
        message: `${testType} test completed successfully`,
        timestamp: new Date().toISOString(),
        response_time: Math.floor(Math.random() * 300) + 100
      };
      
      setTestResults(prev => [newTestResult, ...prev.slice(0, 4)]);
      
      console.log('Test completed successfully');
    } catch (error) {
      console.error('Test failed:', error);
    } finally {
      setTesting(false);
    }
  };

  const handleInputChange = (field, value) => {
    setConfig(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    console.log('Copied to clipboard');
  };

  const getStatusBadge = (status) => {
    const variants = {
      success: 'bg-green-100 text-green-800',
      error: 'bg-red-100 text-red-800',
      warning: 'bg-yellow-100 text-yellow-800',
      pending: 'bg-blue-100 text-blue-800'
    };
    
    return (
      <Badge className={variants[status] || 'bg-gray-100 text-gray-800'}>
        {status.toUpperCase()}
      </Badge>
    );
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  const maskToken = (token) => {
    if (!token || token.length < 8) return token;
    return token.substring(0, 8) + '...' + token.substring(token.length - 8);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">WhatsApp API Configuration</h2>
          <p className="text-gray-600">Configure WhatsApp Business API settings for your clinic</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            variant="outline" 
            onClick={() => handleTestConnection('quick')}
            disabled={testing}
          >
            {testing ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <TestTube className="h-4 w-4 mr-2" />
            )}
            Quick Test
          </Button>
          <Button 
            onClick={handleSaveConfiguration}
            disabled={saving}
            className="craft-ai-teal"
          >
            {saving ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            Save Configuration
          </Button>
        </div>
      </div>

      {/* Status Alert */}
      <Alert className={config.is_webhook_verified ? 'border-green-200 bg-green-50' : 'border-yellow-200 bg-yellow-50'}>
        {config.is_webhook_verified ? (
          <CheckCircle className="h-4 w-4 text-green-600" />
        ) : (
          <AlertCircle className="h-4 w-4 text-yellow-600" />
        )}
        <AlertTitle>
          {config.is_webhook_verified ? 'Configuration Active' : 'Configuration Incomplete'}
        </AlertTitle>
        <AlertDescription>
          {config.is_webhook_verified 
            ? 'Your WhatsApp API is properly configured and receiving messages.'
            : 'Please complete the configuration and verify your webhook to start receiving messages.'
          }
        </AlertDescription>
      </Alert>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="configuration">API Configuration</TabsTrigger>
          <TabsTrigger value="webhook">Webhook Settings</TabsTrigger>
          <TabsTrigger value="testing">Testing & Logs</TabsTrigger>
        </TabsList>

        {/* Configuration Tab */}
        <TabsContent value="configuration">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="h-5 w-5" />
                  <span>Basic Configuration</span>
                </CardTitle>
                <CardDescription>
                  Configure your WhatsApp Business API credentials
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Phone Number ID */}
                <div className="space-y-2">
                  <Label htmlFor="phone_number_id">Phone Number ID</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="phone_number_id"
                      value={config.phone_number_id}
                      onChange={(e) => handleInputChange('phone_number_id', e.target.value)}
                      placeholder="Enter your WhatsApp Phone Number ID"
                    />
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => copyToClipboard(config.phone_number_id)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-gray-500">
                    Found in your WhatsApp Business Account dashboard
                  </p>
                </div>

                {/* Access Token */}
                <div className="space-y-2">
                  <Label htmlFor="access_token">Access Token</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="access_token"
                      type={showAccessToken ? 'text' : 'password'}
                      value={config.access_token}
                      onChange={(e) => handleInputChange('access_token', e.target.value)}
                      placeholder="Enter your WhatsApp Access Token"
                    />
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => setShowAccessToken(!showAccessToken)}
                    >
                      {showAccessToken ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => copyToClipboard(config.access_token)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-gray-500">
                    Your permanent access token from Facebook Developer Console
                  </p>
                </div>

                {/* Business Account ID */}
                <div className="space-y-2">
                  <Label htmlFor="business_account_id">Business Account ID</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="business_account_id"
                      value={config.business_account_id}
                      onChange={(e) => handleInputChange('business_account_id', e.target.value)}
                      placeholder="Enter your WhatsApp Business Account ID"
                    />
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => copyToClipboard(config.business_account_id)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* App Credentials */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="app_id">App ID</Label>
                    <Input
                      id="app_id"
                      value={config.app_id}
                      onChange={(e) => handleInputChange('app_id', e.target.value)}
                      placeholder="Facebook App ID"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="app_secret">App Secret</Label>
                    <div className="flex space-x-2">
                      <Input
                        id="app_secret"
                        type={showAppSecret ? 'text' : 'password'}
                        value={config.app_secret}
                        onChange={(e) => handleInputChange('app_secret', e.target.value)}
                        placeholder="Facebook App Secret"
                      />
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={() => setShowAppSecret(!showAppSecret)}
                      >
                        {showAppSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Webhook Tab */}
        <TabsContent value="webhook">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Webhook className="h-5 w-5" />
                  <span>Webhook Configuration</span>
                </CardTitle>
                <CardDescription>
                  Configure webhook settings to receive WhatsApp messages
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Webhook URL */}
                <div className="space-y-2">
                  <Label htmlFor="webhook_url">Webhook URL</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="webhook_url"
                      value={config.webhook_url}
                      onChange={(e) => handleInputChange('webhook_url', e.target.value)}
                      placeholder="https://your-domain.com/webhook/whatsapp"
                    />
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => copyToClipboard(config.webhook_url)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-gray-500">
                    This URL will receive WhatsApp webhook events
                  </p>
                </div>

                {/* Verify Token */}
                <div className="space-y-2">
                  <Label htmlFor="webhook_verify_token">Webhook Verify Token</Label>
                  <div className="flex space-x-2">
                    <Input
                      id="webhook_verify_token"
                      value={config.webhook_verify_token}
                      onChange={(e) => handleInputChange('webhook_verify_token', e.target.value)}
                      placeholder="Enter a secure verify token"
                    />
                    <Button 
                      variant="outline" 
                      size="icon"
                      onClick={() => copyToClipboard(config.webhook_verify_token)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                  <p className="text-sm text-gray-500">
                    Use this token to verify webhook requests from WhatsApp
                  </p>
                </div>

                {/* Webhook Events */}
                <div className="space-y-2">
                  <Label>Webhook Events</Label>
                  <div className="space-y-3">
                    {['messages', 'messaging_postbacks', 'messaging_optins', 'messaging_referrals'].map((event) => (
                      <div key={event} className="flex items-center space-x-2">
                        <Switch
                          id={event}
                          checked={config.webhook_events.includes(event)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              handleInputChange('webhook_events', [...config.webhook_events, event]);
                            } else {
                              handleInputChange('webhook_events', config.webhook_events.filter(e => e !== event));
                            }
                          }}
                        />
                        <Label htmlFor={event} className="capitalize">
                          {event.replace('_', ' ')}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Webhook Status */}
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium">Webhook Status</span>
                    {getStatusBadge(config.is_webhook_verified ? 'success' : 'pending')}
                  </div>
                  <p className="text-sm text-gray-600">
                    {config.is_webhook_verified 
                      ? 'Webhook is verified and receiving events'
                      : 'Webhook verification pending'
                    }
                  </p>
                  {config.last_test_time && (
                    <p className="text-xs text-gray-500 mt-1">
                      Last verified: {formatDateTime(config.last_test_time)}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Testing Tab */}
        <TabsContent value="testing">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TestTube className="h-5 w-5" />
                  <span>API Testing</span>
                </CardTitle>
                <CardDescription>
                  Test your WhatsApp API configuration and view recent test results
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Test Buttons */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button 
                    variant="outline" 
                    onClick={() => handleTestConnection('send_message')}
                    disabled={testing}
                    className="h-20 flex-col space-y-2"
                  >
                    <MessageSquare className="h-6 w-6" />
                    <span>Test Send Message</span>
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleTestConnection('webhook_verification')}
                    disabled={testing}
                    className="h-20 flex-col space-y-2"
                  >
                    <Webhook className="h-6 w-6" />
                    <span>Test Webhook</span>
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => handleTestConnection('full')}
                    disabled={testing}
                    className="h-20 flex-col space-y-2"
                  >
                    <Shield className="h-6 w-6" />
                    <span>Full Test Suite</span>
                  </Button>
                </div>

                {/* Test Results */}
                <div className="space-y-4">
                  <h4 className="font-medium">Recent Test Results</h4>
                  {testResults.map((result) => (
                    <div key={result.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-3">
                          <span className="font-medium capitalize">
                            {result.test_type.replace('_', ' ')}
                          </span>
                          {getStatusBadge(result.status)}
                        </div>
                        <div className="text-sm text-gray-500">
                          {formatDateTime(result.timestamp)}
                        </div>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{result.message}</p>
                      <div className="text-xs text-gray-500">
                        Response time: {result.response_time}ms
                      </div>
                    </div>
                  ))}
                </div>

                {testResults.length === 0 && (
                  <div className="text-center py-8">
                    <TestTube className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No test results yet</p>
                    <p className="text-sm text-gray-400">Run a test to see results here</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

