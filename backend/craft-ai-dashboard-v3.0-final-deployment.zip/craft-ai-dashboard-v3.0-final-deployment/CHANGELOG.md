# Changelog

All notable changes to the Craft AI Dashboard project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [3.0.0] - 2024-01-23

### 🎉 Major Release - Enhanced Call Data Analytics

This major release focuses on streamlining the user experience and enhancing call data analytics capabilities.

### ✨ Added

#### Call Data Analytics Enhancement
- **Call Reason Column**: Added dedicated "Call Reason" column to replace "Lead Status" in call data table
- **Call Reason Filtering**: Implemented comprehensive filtering system for call reasons including:
  - Birthday Call
  - Appointment Confirmation
  - Booking Call
  - Follow-up Call
  - Consultation Call
  - Reminder Call
  - Sales Call
  - Support Call
  - General Inquiry
  - Billing Inquiry
- **Advanced Filter UI**: New "All Reasons" dropdown filter with real-time filtering capabilities
- **Backend API Support**: Added `/calls/reasons` endpoint for dynamic call reason management
- **Database Seeding**: Automated creation of 50+ demo calls with various call reasons for testing

#### User Experience Improvements
- **Professional Branding**: Integrated custom Craft AI logo throughout the application
- **Logo Visibility**: Fixed logo display on login page with proper asset path configuration
- **Streamlined Navigation**: Removed Outbound Calls dashboard for simplified workflow
- **Single Header Panel**: Consolidated header panels across all modules for consistent UI

#### Technical Enhancements
- **Enhanced API**: Updated call filtering API to support call reason parameters
- **Improved Data Model**: Enhanced call data structure to support reason-based analytics
- **Frontend Optimization**: Updated React components for better performance and user experience

### 🔄 Changed

#### Navigation Structure
- **Removed Outbound Calls**: Eliminated separate Outbound Calls dashboard to reduce complexity
- **Unified Call Management**: Consolidated all call-related functionality into the enhanced Call Data section
- **Sidebar Cleanup**: Streamlined navigation menu for better user experience

#### Call Data Interface
- **Column Restructure**: Replaced "Lead Status" column with "Call Reason" column
- **Filter Enhancement**: Upgraded filtering system with three-tier filtering (Status, Direction, Call Reason)
- **Table Layout**: Improved table layout for better data visibility and user interaction

#### Header System
- **Consistent Headers**: Implemented single header panel across all modules
- **Removed Duplicates**: Eliminated duplicate header panels from the main dashboard
- **Unified Search**: Centralized search functionality in the main header

### 🐛 Fixed

#### Authentication & Login
- **Login Functionality**: Resolved login issues and ensured proper authentication flow
- **Logo Display**: Fixed logo visibility issues on the login page
- **Session Management**: Improved session handling and user state management

#### User Interface
- **Header Duplication**: Removed duplicate header panels causing UI inconsistency
- **Navigation Issues**: Fixed navigation between modules and proper page title display
- **Responsive Design**: Improved mobile and tablet compatibility

#### Data Management
- **Call Data Loading**: Fixed issues with call data not displaying properly
- **Filter Functionality**: Resolved filtering problems and improved filter responsiveness
- **Database Initialization**: Fixed demo data creation and database seeding

### 🗑️ Removed

#### Deprecated Features
- **Outbound Calls Dashboard**: Completely removed separate outbound calls module
- **Lead Status Column**: Replaced with more relevant Call Reason column
- **Duplicate Components**: Removed redundant UI components and code

#### Unused Dependencies
- **Legacy Code**: Cleaned up unused imports and deprecated functions
- **Redundant Routes**: Removed unused API endpoints and routes

### 🔧 Technical Details

#### Backend Changes
```python
# New API endpoint for call reasons
@calls_bp.route("/reasons", methods=["GET"])
@jwt_required()
@same_clinic_required
def get_call_reasons():
    # Returns list of available call reasons
    
# Updated calls filtering
@calls_bp.route("/", methods=["GET"])
def get_calls():
    # Now supports call_reason parameter
    call_reason = request.args.get("call_reason", None)
    if call_reason:
        query = query.filter_by(call_type=call_reason)
```

#### Frontend Changes
```javascript
// Enhanced CallData component
const [callReasonFilter, setCallReasonFilter] = useState('all');
const [callReasons, setCallReasons] = useState([]);

// New filtering logic
const filteredCalls = calls.filter(call => {
    const matchesCallReason = callReasonFilter === 'all' || call.call_type === callReasonFilter;
    return matchesSearch && matchesStatus && matchesDirection && matchesCallReason;
});
```

#### Database Schema Updates
```sql
-- Call reasons are stored in the existing call_type field
-- New demo data includes diverse call reasons for testing
INSERT INTO calls (call_type, ...) VALUES 
    ('Birthday Call', ...),
    ('Appointment Confirmation', ...),
    ('Booking Call', ...);
```

### 📊 Performance Improvements

- **Faster Filtering**: Optimized call data filtering for better performance
- **Reduced Bundle Size**: Removed unused components and dependencies
- **Improved Loading**: Enhanced data loading and caching strategies
- **Better Responsiveness**: Optimized UI rendering for smoother user experience

### 🔐 Security Enhancements

- **Authentication Flow**: Improved login security and session management
- **API Security**: Enhanced API endpoint security and validation
- **Input Validation**: Strengthened input validation for call reason filtering

### 📱 Compatibility

- **Browser Support**: Tested on Chrome 90+, Firefox 88+, Safari 14+
- **Mobile Devices**: Improved responsive design for mobile and tablet
- **Screen Readers**: Enhanced accessibility for screen reader compatibility

### 🚀 Deployment

- **Live Application**: https://w5hni7c7qomo.manus.space
- **Demo Credentials**: Demo Clinic / demo / demo
- **Super Admin**: craft_admin / CraftAI2024!

---

## [2.2.0] - 2024-01-20

### Added
- Enhanced Outbound Calls module with call type filtering
- Header panels on all modules for consistent navigation
- Call type filtering similar to Call Data section
- Improved user interface consistency

### Changed
- Updated navigation to include header panels on all pages
- Enhanced filtering capabilities across modules

### Fixed
- Login authentication issues
- Dashboard display problems
- Input field functionality on login page

---

## [2.1.0] - 2024-01-18

### Added
- Automatic demo account creation on deployment
- Super admin account functionality
- Database initialization improvements

### Fixed
- Login functionality completely resolved
- Demo account creation automated
- Database seeding issues

---

## [2.0.0] - 2024-01-15

### Added
- Multi-clinic management support
- JWT-based authentication system
- Comprehensive dashboard with real-time metrics
- Call data management and analytics
- WhatsApp integration and message management
- SMS inbox and messaging capabilities
- Telegram integration
- Appointment scheduling system
- User management and role-based access

### Technical Stack
- Backend: Flask (Python) with SQLAlchemy
- Frontend: React 18 with Vite
- UI: Tailwind CSS + shadcn/ui components
- Database: SQLite with PostgreSQL support
- Authentication: JWT tokens
- Deployment: Manus Cloud Platform

---

## [1.0.0] - 2024-01-10

### Added
- Initial release of Craft AI Dashboard
- Basic clinic management functionality
- User authentication system
- Simple dashboard interface
- Call logging capabilities
- Basic reporting features

---

## Version Comparison

| Feature | v1.0.0 | v2.0.0 | v2.1.0 | v2.2.0 | v3.0.0 |
|---------|--------|--------|--------|--------|--------|
| Multi-clinic Support | ❌ | ✅ | ✅ | ✅ | ✅ |
| JWT Authentication | ❌ | ✅ | ✅ | ✅ | ✅ |
| Call Data Analytics | Basic | ✅ | ✅ | ✅ | Enhanced |
| WhatsApp Integration | ❌ | ✅ | ✅ | ✅ | ✅ |
| SMS Management | ❌ | ✅ | ✅ | ✅ | ✅ |
| Telegram Integration | ❌ | ✅ | ✅ | ✅ | ✅ |
| Appointment System | ❌ | ✅ | ✅ | ✅ | ✅ |
| Outbound Calls Module | ❌ | ❌ | ❌ | ✅ | ❌ (Removed) |
| Call Reason Filtering | ❌ | ❌ | ❌ | ❌ | ✅ |
| Header Panels | ❌ | ❌ | ❌ | ✅ | ✅ (Improved) |
| Custom Logo | ❌ | ❌ | ❌ | ❌ | ✅ |
| Streamlined UI | ❌ | ❌ | ❌ | ❌ | ✅ |

## Upgrade Notes

### Upgrading from v2.2.0 to v3.0.0

#### Breaking Changes
- **Outbound Calls Module Removed**: The separate Outbound Calls dashboard has been removed. All call management is now consolidated in the enhanced Call Data section.
- **Lead Status Column Replaced**: The "Lead Status" column in call data has been replaced with "Call Reason" column.

#### Migration Steps
1. **Data Migration**: Existing call data will automatically use the new call reason structure
2. **Navigation Update**: Remove any bookmarks or links to the Outbound Calls module
3. **User Training**: Train users on the new Call Reason filtering system in Call Data
4. **API Updates**: Update any custom integrations to use the new `/calls/reasons` endpoint

#### New Features to Explore
1. **Call Reason Filtering**: Use the new "All Reasons" dropdown in Call Data
2. **Enhanced Analytics**: Explore call analytics by specific call purposes
3. **Streamlined Navigation**: Enjoy the simplified navigation without Outbound Calls
4. **Professional Branding**: Notice the new Craft AI logo throughout the application

### Upgrading from v2.1.0 to v2.2.0
- No breaking changes
- New features are additive
- Existing functionality remains unchanged

### Upgrading from v2.0.0 to v2.1.0
- Automatic demo account creation
- No manual intervention required
- Improved deployment reliability

## Support

For upgrade assistance or questions about any version:
- **Documentation**: Complete guides in the `docs/` directory
- **Live Demo**: https://w5hni7c7qomo.manus.space
- **Support Email**: support@craftai.com

---

**Note**: This changelog follows semantic versioning. Major version changes (3.0.0) include breaking changes, minor versions (2.1.0) add new features, and patch versions (2.0.1) include bug fixes only.

